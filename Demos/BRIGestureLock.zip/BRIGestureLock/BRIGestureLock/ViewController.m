//
//  ViewController.m
//  BRIGestureLock
//
//  Created by ByRongInvest on 15/12/9.
//  Copyright © 2015年 ByRongInvest. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <BRIGestureLockDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.lock.delegate = self;
}


- (void)gestureLock:(BRIGestureLock *)gesture didCompleteWithPasswordString:(NSString *)string {
    NSLog(@"%@", string);
    
    gesture.match = NO;
}


@end
