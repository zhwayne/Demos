//
//  ViewController.h
//  BRIGestureLock
//
//  Created by ByRongInvest on 15/12/9.
//  Copyright © 2015年 ByRongInvest. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BRIGestureLock.h"

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet BRIGestureLock *lock;

@end

